const toggle = document.getElementById("themeToggle")

toggle.addEventListener("click", () => {
  document.body.classList.toggle("light")

  if(document.body.classList.contains("light")){
    toggle.textContent = "☀️"
    localStorage.setItem("theme", "light")
  } else {
    toggle.textContent = "🌙"
    localStorage.setItem("theme", "dark")
  }
})

window.onload = () => {
  const saved = localStorage.getItem("theme")
  if(saved === "light"){
    document.body.classList.add("light")
    toggle.textContent = "☀️"
  }
}
// === МОДАЛЬНОЕ ОКНО ПОИСКА ===
const searchToggle = document.getElementById("searchToggle");
const searchModal = document.getElementById("searchModal");
const modalClose = document.getElementById("modalClose");

searchToggle.onclick = () => searchModal.classList.add("active");
modalClose.onclick = () => searchModal.classList.remove("active");

// === ФИЛЬТР УНИВЕРСИТЕТОВ ===
const filterBtns = document.querySelectorAll(".filter-btn");
const cards = document.querySelectorAll(".university-card");

filterBtns.forEach(btn => {
  btn.addEventListener("click", () => {
    const type = btn.dataset.filter;

    filterBtns.forEach(b => b.classList.remove("active"));
    btn.classList.add("active");

    cards.forEach(card => {
      if (type === "all" || card.dataset.type === type) {
        card.style.display = "block";
      } else {
        card.style.display = "none";
      }
    });
  });
});

// === СРАВНЕНИЕ ===
let selected = [];

document.querySelectorAll(".btn-compare").forEach(btn => {
  btn.addEventListener("click", () => {
    if (selected.length >= 3) {
      alert("Можно выбрать только 3");
      return;
    }

    const card = btn.closest(".university-card");
    const name = card.querySelector(".univ-name").innerText;
    const stats = card.querySelectorAll(".stat-value");

    const data = {
      name,
      qs: stats[0].innerText,
      programs: stats[1].innerText,
      students: stats[2].innerText,
      cost: "≈1 200 000 тг"
    };

    selected.push(data);
    updateCompareUI();
  });
});

function updateCompareUI() {
  selected.forEach((u, i) => {
    document.getElementById("header" + (i+1)).innerText = u.name;
    document.getElementById("qs" + (i+1)).innerText = u.qs;
    document.getElementById("prog" + (i+1)).innerText = u.programs;
    document.getElementById("stud" + (i+1)).innerText = u.students;
    document.getElementById("cost" + (i+1)).innerText = u.cost;
  });

  if (selected.length >= 2) {
    document.querySelector(".btn-compare-start").disabled = false;
  }
}

document.querySelector(".btn-compare-start").onclick = () => {
  document.getElementById("compareTable").style.display = "block";
  scrollTo({ top: compare.offsetTop, behavior: "smooth" });
};

// === ПОИСК С БЭКЕНДА ===
document.querySelector(".search-btn").onclick = async () => {
  const input = document.getElementById("mainSearch").value;

  const res = await fetch(`/api/search?q=${input}`);
  const data = await res.json();

  if (data.length === 0) {
    alert("Ничего не найдено");
  } else {
    alert("Найдено: " + data.map(u => u.name).join(", "));
  }
};

// === КАЛЬКУЛЯТОР ГРАНТА ===
document.querySelector(".cta-form button").onclick = () => {
  const score = document.querySelector(".cta-form input").value;

  if (score > 110) alert("🔥 Шанс высокий!");
  else if (score > 85) alert("⚠ Средний шанс");
  else alert("⛔ Малый шанс");
};









