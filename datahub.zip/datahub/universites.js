const { MongoClient } = require('mongodb');
const universities = require('./universities.json');

const uri = "mongodb+srv://admin:joma05@cluster0.seo380b.mongodb.net";
const client = new MongoClient(uri);

async function loadData() {
  try {
    await client.connect();
    const db = client.db("universityPlatform");
    const collection = db.collection("universities");
    await collection.deleteMany({});
    const result = await collection.insertMany(universities);
    console.log(`${result.insertedCount} университетов добавлено.`);
  } finally {
    await client.close();
  }
}

loadData().catch(console.dir);
