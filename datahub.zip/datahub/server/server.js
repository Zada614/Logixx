import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import { MongoClient, ObjectId } from 'mongodb';
import bcrypt from 'bcryptjs';

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static("public")); // Твой html будет открываться




app.use(express.urlencoded({ extended: true }));
app.set('view engine', 'ejs');


/* ==========================
   ПОДКЛЮЧЕНИЕ К MONGODB
========================== */





/* ==========================
   МОДЕЛЬ УНИВЕРСИТЕТА
========================== */




/* ==========================
   РОУТЫ (маршруты)
========================== */

// Проверка сервера
app.get("/api", (req, res) => {
  res.json({ message: "✅ Сервер DataHub работает" });
});


// Получить список университетов
app.get("/api/universities", async (req, res) => {
  const universities = await University.find();
  res.json(universities);
});


// Поиск университета по названию
app.get("/api/search", async (req, res) => {
  const { q } = req.query;

  if (!q) {
    return res.json([]);
  }

  const result = await University.find({
    name: { $regex: q, $options: "i" }
  });

  res.json(result);
});


// Добавить университет
app.post("/api/university", async (req, res) => {
  try {
    const uni = new University(req.body);
    await uni.save();

    res.json({ message: "✅ Университет добавлен в базу" });

  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});


// Удалить университет
app.delete("/api/university/:id", async (req, res) => {
  try {
    await University.findByIdAndDelete(req.params.id);
    res.json({ message: "❌ Университет удалён" });

  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});


/* ==========================
    ЗАПУСК СЕРВЕРА
========================== */

const PORT = process.env.PORT || 5000;


app.get('/admin', async (req, res) => {
  await client.connect();
  const db = client.db("universityPlatform");
  const universities = await db.collection("universities").find().toArray();
  res.render('admin', { universities });
});

app.post('/admin/add', async (req, res) => {
  const db = client.db("universityPlatform");
  await db.collection("universities").insertOne(req.body);
  res.redirect('/admin');
});

app.post('/admin/delete/:id', async (req, res) => {
  const db = client.db("universityPlatform");
  await db.collection("universities").deleteOne({ _id: ObjectId(req.params.id) });
  res.redirect('/admin');
});

// Личный кабинет
app.get('/dashboard/:userId', async (req, res) => {
  const db = client.db("universityPlatform");
  const user = await db.collection("users").findOne({ _id: ObjectId(req.params.userId) });
  const saved = await db.collection("universities").find({
    _id: { $in: (user.savedUniversities || []).map(id => ObjectId(id)) }
  }).toArray();
  res.render('dashboard', { user, saved });
});

app.listen(PORT, () => {
  console.log(`✅ Сервер запущен: http://localhost:${PORT}`);
});